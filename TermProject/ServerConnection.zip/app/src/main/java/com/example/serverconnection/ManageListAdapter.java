package com.example.serverconnection;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class ManageListAdapter extends BaseAdapter {

    private Context context;
    private List<Manage> manageList;
    private Fragment parent;

    public ManageListAdapter (Context context, List<Manage> manageList, Fragment parent) {
        this.context = context;
        this.manageList = manageList;
        this.parent = parent;
    }
    @Override
    public int getCount() {
        return manageList.size();
    }

    @Override
    public Object getItem(int i) {
        return manageList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.manage, null);
        TextView userID = (TextView) v.findViewById(R.id.userID);
        TextView userPassword = (TextView) v.findViewById(R.id.userPassword);
        TextView userName = (TextView) v.findViewById(R.id.userName);
        TextView userAge = (TextView) v.findViewById(R.id.userAge);

        userID.setText(manageList.get(i).getUserID());
        userPassword.setText(manageList.get(i).getUserPassword());
        userName.setText(manageList.get(i).getUserName());
        userAge.setText(manageList.get(i).getUserAge()+"");

        return v;
    }
}
