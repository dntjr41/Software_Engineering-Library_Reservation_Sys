package com.example.serverconnection;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class DeleteRequest extends StringRequest {

    final static private String URL = "http://han201835461.dothome.co.kr/Delete.php";
    private Map<String, String> map;

    public DeleteRequest(String bookID, String bookName, String bookType, String bookYear, Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null);

        map = new HashMap<>();
        map.put("bookID", bookID);
        map.put("bookName", bookName);
        map.put("bookType", bookType);
        map.put("bookYear", bookYear);
    }

    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        return map;
    }
}