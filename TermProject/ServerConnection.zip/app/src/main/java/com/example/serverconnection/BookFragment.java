package com.example.serverconnection;

import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class BookFragment extends Fragment {

    private ArrayAdapter typeAdapter;
    private Spinner typeSpinner;
    private ArrayAdapter yearAdapter;
    private static Spinner yearSpinner;

    private String bookType = "";
    private String bookYear = "";

    private ListView bookListView;
    private BookListAdapter adapter;
    private List<Book> bookList;

    @Override
    public void onActivityCreated (Bundle b) {
        super.onActivityCreated(b);

        typeSpinner = (Spinner) getView().findViewById(R.id.bookTypeSpinner);
        yearSpinner = (Spinner) getView().findViewById(R.id.bookYearSpinner);

        typeAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.type, android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(typeAdapter);

        yearAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.year, android.R.layout.simple_spinner_dropdown_item);
        yearSpinner.setAdapter(yearAdapter);

        bookListView = (ListView) getView().findViewById(R.id.bookListView);
        bookList = new ArrayList<Book>();
        adapter = new BookListAdapter(getContext().getApplicationContext(), bookList, this);
        bookListView.setAdapter(adapter);

        Button searchButton = (Button)getView().findViewById(R.id.searchButton);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new BackgroundTask().execute();
            }
        });
    }

    class BackgroundTask extends AsyncTask<Void, Void, String>
    {
        String target;

        @Override
        protected void onPreExecute() {
            try {
                target="http://han201835461.dothome.co.kr/BookList.php?bookType=" + URLEncoder.encode(typeSpinner.getSelectedItem().toString(), "UTF-8") +
                        "&bookYear=" + URLEncoder.encode(yearSpinner.getSelectedItem().toString().substring(0,4), "UTF-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL(target);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader (new InputStreamReader(inputStream));
                String temp;
                StringBuilder stringBuilder = new StringBuilder();
                while((temp = bufferedReader.readLine()) != null)
                {
                    stringBuilder.append(temp + "\n");
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return stringBuilder.toString().trim();
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        public void onProgressUpdate(Void... values) { super.onProgressUpdate();}

        @Override
        public void onPostExecute(String result) {
            try {
                bookList.clear();
                JSONObject jsonObject = new JSONObject(result);
                JSONArray jsonArray = jsonObject.getJSONArray("response");

                int count = 0;
                int bookID;
                String bookName;
                String bookType;
                int bookYear;

                while(count < jsonArray.length())
                {
                    JSONObject object = jsonArray.getJSONObject(count);
                    bookID = object.getInt("bookID");
                    bookName = object.getString("bookName");
                    bookType = object.getString("bookType");
                    bookYear = object.getInt("bookYear");

                    Book book = new Book(bookID, bookName, bookType, bookYear);
                    bookList.add(book);
                    count++;
                }

                if(count==0)
                {
                    AlertDialog dialog;
                    AlertDialog.Builder builder = new AlertDialog.Builder(BookFragment.this.getActivity());
                    dialog = builder.setMessage("There is no book that meets the criteria.").setPositiveButton("check",null).create();
                    dialog.show();
                }
                adapter.notifyDataSetChanged();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_book,container,false);
    }
}
