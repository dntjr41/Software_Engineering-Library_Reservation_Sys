package com.example.serverconnection;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.List;

public class AddAdapter extends BaseAdapter {

    private Context context;
    private List<Book> bookList;
    private Fragment parent;

    public AddAdapter (Context context, List<Book> bookList, Fragment parent) {
        this.context = context;
        this.bookList = bookList;
        this.parent = parent;
    }
    @Override
    public int getCount() {
        return bookList.size();
    }

    @Override
    public Object getItem(int i) {
        return bookList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.booklist, null);
        TextView bookID = (TextView) v.findViewById(R.id.id);
        TextView bookName = (TextView) v.findViewById(R.id.name);
        TextView bookType = (TextView) v.findViewById(R.id.type);
        TextView bookYear = (TextView) v.findViewById(R.id.year);

        bookID.setText(bookList.get(i).getBookID()+"");
        bookName.setText(bookList.get(i).getBookName());
        bookType.setText(bookList.get(i).getBookType());
        bookYear.setText(bookList.get(i).getBookYear()+"");

        return v;
    }
}
