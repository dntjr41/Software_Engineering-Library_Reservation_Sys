package com.example.serverconnection;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

public class UserBookAdapter extends BaseAdapter {

    private Context context;
    private List<Book> bookList;
    private Fragment parent;
    private String userID = MainActivity.userID;

    public UserBookAdapter (Context context, List<Book> bookList, Fragment parent) {
        this.context = context;
        this.bookList = bookList;
        this.parent = parent;
    }
    @Override
    public int getCount() {
        return bookList.size();
    }

    @Override
    public Object getItem(int i) {
        return bookList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.book_return, null);
        TextView bookID = (TextView) v.findViewById(R.id.id);
        TextView bookType = (TextView) v.findViewById(R.id.type);
        TextView bookName = (TextView) v.findViewById(R.id.name);
        TextView bookYear = (TextView) v.findViewById(R.id.year);

        bookID.setText(bookList.get(i).getBookID()+"");
        bookType.setText(bookList.get(i).getBookType());
        bookName.setText(bookList.get(i).getBookName());
        bookYear.setText(bookList.get(i).getBookYear()+"");

        v.setTag(bookList.get(i).getBookID());

        Button returnButton = (Button) v.findViewById(R.id.returnBtn);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            if(success) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(parent.getActivity());
                                AlertDialog dialog = builder.setMessage("You return the book!").setPositiveButton("check", null).create();
                                dialog.show();
                                bookList.remove(i);
                                notifyDataSetChanged();
                            }
                            else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(parent.getActivity());
                                AlertDialog dialog = builder.setMessage("Return failure").setNegativeButton("retry", null).create();
                                dialog.show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                ReturnRequest returnBookRequest = new ReturnRequest(userID, bookList.get(i).getBookID()+"", responseListener);
                RequestQueue queue = Volley.newRequestQueue(parent.getActivity());
                queue.add(returnBookRequest);
            }
        });

        return v;
    }

}
