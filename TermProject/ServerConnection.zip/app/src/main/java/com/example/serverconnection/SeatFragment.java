package com.example.serverconnection;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class SeatFragment extends Fragment {

    private ImageButton S1, S2, S3, S4, S5, S6, S7, S8, S9;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_seat,container,false);
    }
    @Override
    public void onActivityCreated (Bundle b) {
        super.onActivityCreated(b);

        S1 = (ImageButton)getView().findViewById(R.id.seat1);
        S1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Number 1 reservation completed", Toast.LENGTH_LONG).show();
                S1.setBackgroundColor(getResources().getColor(R.color.colorGray));
            }
        });

        S2 = (ImageButton)getView().findViewById(R.id.seat2);
        S2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Number 2 reservation completed", Toast.LENGTH_LONG).show();
                S2.setBackgroundColor(getResources().getColor(R.color.colorGray));
            }
        });

        S3 = (ImageButton)getView().findViewById(R.id.seat3);
        S3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Number 3 reservation completed", Toast.LENGTH_LONG).show();
                S3.setBackgroundColor(getResources().getColor(R.color.colorGray));
            }
        });

        S4 = (ImageButton)getView().findViewById(R.id.seat4);
        S4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Number 4 reservation completed", Toast.LENGTH_LONG).show();
                S4.setBackgroundColor(getResources().getColor(R.color.colorGray));
            }
        });

        S5 = (ImageButton)getView().findViewById(R.id.seat5);
        S5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Number 5 reservation completed", Toast.LENGTH_LONG).show();
                S5.setBackgroundColor(getResources().getColor(R.color.colorGray));
            }
        });

        S6 = (ImageButton)getView().findViewById(R.id.seat6);
        S6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Number 6 reservation completed", Toast.LENGTH_LONG).show();
                S6.setBackgroundColor(getResources().getColor(R.color.colorGray));
            }
        });

        S7 = (ImageButton)getView().findViewById(R.id.seat7);
        S7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Number 7 reservation completed", Toast.LENGTH_LONG).show();
                S7.setBackgroundColor(getResources().getColor(R.color.colorGray));
            }
        });

        S8 = (ImageButton)getView().findViewById(R.id.seat8);
        S8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Number 8 reservation completed", Toast.LENGTH_LONG).show();
                S8.setBackgroundColor(getResources().getColor(R.color.colorGray));
            }
        });

        S9 = (ImageButton)getView().findViewById(R.id.seat9);
        S9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Number 9 reservation completed", Toast.LENGTH_LONG).show();
                S9.setBackgroundColor(getResources().getColor(R.color.colorGray));
            }
        });
    }
}
