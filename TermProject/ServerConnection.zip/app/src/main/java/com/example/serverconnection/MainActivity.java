package com.example.serverconnection;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    public static String userID;
    public static int bookID;
    private TextView userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);

        userID = getIntent().getStringExtra("userID");

        final Button bookButton = (Button)findViewById(R.id.bookButton);
        final Button loanBookButton = (Button)findViewById(R.id.loanBookButton);
        final Button seatButton = (Button)findViewById(R.id.seatButton);

        final LinearLayout notice = (LinearLayout)findViewById(R.id.notice);

        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notice.setVisibility(View.GONE);
                bookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                loanBookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                seatButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment, new BookFragment());
                fragmentTransaction.commit();
            }
        });

        loanBookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notice.setVisibility(View.GONE);
                bookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                loanBookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                seatButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment, new UserBookFragment());
                fragmentTransaction.commit();
            }
        });

        seatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notice.setVisibility(View.GONE);
                bookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                loanBookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                seatButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment, new SeatFragment());
                fragmentTransaction.commit();
            }
        });

    }


    //뒤로 가기 버튼을 두 번 눌러 앱 종료하기
    private long lastTimeBackPressed;

    @Override
    public void onBackPressed() {
        if(System.currentTimeMillis() - lastTimeBackPressed < 1500)
        {
            finish();
            return;
        }
        Toast.makeText(this,"Press the back button one more time to exit.", Toast.LENGTH_SHORT).show();
        lastTimeBackPressed = System.currentTimeMillis();
    }

}