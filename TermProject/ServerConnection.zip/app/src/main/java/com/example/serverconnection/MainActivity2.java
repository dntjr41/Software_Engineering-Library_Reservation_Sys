package com.example.serverconnection;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity2 extends AppCompatActivity {

    public static int bookID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        bookID = getIntent().getIntExtra("bookID", bookID);

        final Button addBookButton = (Button)findViewById(R.id.addBookButton);
        final Button deleteBookButton = (Button)findViewById(R.id.deleteBookButton);
        final Button manageButton = (Button)findViewById(R.id.manageButton);

        final LinearLayout notice = (LinearLayout)findViewById(R.id.notice);

        addBookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notice.setVisibility(View.GONE);
                addBookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                deleteBookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                manageButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment, new AddFragment());
                fragmentTransaction.commit();
            }
        });

        deleteBookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notice.setVisibility(View.GONE);
                addBookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                deleteBookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                manageButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment, new DeleteFragment());
                fragmentTransaction.commit();
            }
        });

        manageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notice.setVisibility(View.GONE);
                addBookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                deleteBookButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                manageButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment, new manageFragment());
                fragmentTransaction.commit();
            }
        });
    }


    public void mOnPopupClick(View v){
        //Invoke pop-up (Activity) with time record
        Intent intent = new Intent(this, AddActivity.class);
        startActivityForResult(intent, 1);
    }

    //뒤로 가기 버튼을 두 번 눌러 앱 종료하기
    private long lastTimeBackPressed;

    @Override
    public void onBackPressed() {
        if(System.currentTimeMillis() - lastTimeBackPressed < 1500)
        {
            finish();
            return;
        }
        Toast.makeText(this,"Press the back button one more time to exit.", Toast.LENGTH_SHORT).show();
        lastTimeBackPressed = System.currentTimeMillis();
    }

}
