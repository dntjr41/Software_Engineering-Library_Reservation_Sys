package com.example.serverconnection;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class ReturnRequest extends StringRequest {

    final static private String URL = "http://han201835461.dothome.co.kr/Return.php";
    private Map<String, String> map;

    public ReturnRequest(String userID, String bookID, Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null);

        map = new HashMap<>();
        map.put("userID", userID);
        map.put("bookID", bookID);
    }

    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        return map;
    }
}
