package com.example.serverconnection;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class DeleteAdapter extends BaseAdapter {

    private Context context;
    private List<Book> bookList;
    private Fragment parent;

    public DeleteAdapter(Context context, List<Book> bookList, Fragment parent) {
        this.context = context;
        this.bookList = bookList;
        this.parent = parent;
    }

    @Override
    public int getCount() {
        return bookList.size();
    }

    @Override
    public Object getItem(int i) {
        return bookList.size();
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.book_delete, null);
        TextView bookID = (TextView) v.findViewById(R.id.id);
        TextView bookType = (TextView) v.findViewById(R.id.type);
        TextView bookName = (TextView) v.findViewById(R.id.name);
        TextView bookYear = (TextView) v.findViewById(R.id.year);

        bookID.setText(bookList.get(i).getBookID()+"");
        bookType.setText(bookList.get(i).getBookType());
        bookName.setText(bookList.get(i).getBookName());
        bookYear.setText(bookList.get(i).getBookYear()+"");

        v.setTag(bookList.get(i).getBookID());

        Button deleteButton = (Button) v.findViewById(R.id.deleteBtn);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            if(success) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(parent.getActivity());
                                AlertDialog dialog = builder.setMessage("The book deleted!").setPositiveButton("check", null).create();
                                dialog.show();
                                bookList.remove(i);
                                notifyDataSetChanged();
                            }
                            else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(parent.getActivity());
                                AlertDialog dialog = builder.setMessage("Delete failure").setNegativeButton("retry", null).create();
                                dialog.show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                DeleteRequest deleteRequest = new DeleteRequest(bookList.get(i).getBookID()+"", bookList.get(i).getBookName(), bookList.get(i).getBookType(), bookList.get(i).getBookYear()+"", responseListener);
                RequestQueue queue = Volley.newRequestQueue(parent.getActivity());
                queue.add(deleteRequest);
            }
        });

        return v;
    }
}
