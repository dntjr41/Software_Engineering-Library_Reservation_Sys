package com.example.serverconnection;

public class Book {
    int bookID;
    String bookName;
    String bookType;
    int bookYear;

    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookType() {
        return bookType;
    }

    public void setBookType(String bookType) {
        this.bookType = bookType;
    }

    public int getBookYear() {
        return bookYear;
    }

    public void setBookYear(int bookYear) {
        this.bookYear = bookYear;
    }

    public Book(int bookID, String bookName, String bookType, int bookYear) {
        this.bookID = bookID;
        this.bookName = bookName;
        this.bookType = bookType;
        this.bookYear = bookYear;
    }
}
