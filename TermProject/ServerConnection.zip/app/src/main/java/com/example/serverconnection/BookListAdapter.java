package com.example.serverconnection;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class BookListAdapter extends BaseAdapter {

    private Context context;
    private List<Book> bookList;
    private Fragment parent;

    public BookListAdapter (Context context, List<Book> bookList, Fragment parent) {
        this.context = context;
        this.bookList = bookList;
        this.parent = parent;
    }
    @Override
    public int getCount() {
        return bookList.size();
    }

    @Override
    public Object getItem(int i) {
        return bookList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.book, null);
        TextView bookType = (TextView) v.findViewById(R.id.type);
        TextView bookName = (TextView) v.findViewById(R.id.name);
        TextView bookYear = (TextView) v.findViewById(R.id.year);

        bookType.setText(bookList.get(i).getBookType());
        bookName.setText(bookList.get(i).getBookName());
        bookYear.setText(bookList.get(i).getBookYear()+"");

        v.setTag(bookList.get(i).getBookID());

        Button loanButton = (Button) v.findViewById(R.id.loanBtn);
        loanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userID = MainActivity.userID;
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            if(success) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(parent.getActivity());
                                AlertDialog dialog = builder.setMessage("You loan the book!").setPositiveButton("check", null).create();
                                dialog.show();
                            }
                            else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(parent.getActivity());
                                AlertDialog dialog = builder.setMessage("loan failure").setPositiveButton("check", null).create();
                                dialog.show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                AddBookRequest addBookRequest = new AddBookRequest(userID, bookList.get(i).getBookID()+"", responseListener);
                RequestQueue queue = Volley.newRequestQueue(parent.getActivity());
                queue.add(addBookRequest);

            }
        });

        return v;
    }
}
